./hellminer -c stratum+tcp://ap.luckpool.net:3956 -u RVFP2RM1sJq812KupKtkFp1F6XBBcEBKkm.RVZ -p x --cpu 4
